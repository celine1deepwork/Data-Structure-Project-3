import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ozay
 */
public class GraphMatrix {

    Integer edges[][]; // can be anything, but int vertices handy
    // can be double if there are double weigths
    int numV;
    int numE;

    /**
     * @param V
     */
    public GraphMatrix(int V) {
        this.numV = V;
        edges = new Integer[V][V];
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                edges[i][j] = 0;
            }
        }
    }
    public int graphWeight(int x, int y) {
        //System.out.println(x+" "+y);
        return this.edges[x][y];
    }
    public void addEdge(int from, int to, int weight) {
        edges[from][to] = weight;
        edges[to][from] = weight;
    }

    public boolean isAdjacent(int v1, int v2) {
        return (edges[v1][v2] != 0);
    }

    public int degree(int v) {
        int degree = 0;
        for (int i = 0; i < numV; i++) {
            degree += edges[v][i];
        }
        return degree;
    }
    
    public static int findMaxDegree(GraphMatrix g){
        int degree = 0;
        int maxDegreeVertex = 0;
        for (int i = 0; i < g.numV; i++) {
            System.out.println("Degree: "+g.degree(i));
            if(g.degree(i)>degree){
                degree = g.degree(i);
                maxDegreeVertex = i;
            }
        }
        return maxDegreeVertex;
    }
    
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("");
        for (int i = 0; i < numV; i++) {
            for (int j = 0; j < numV; j++) {
                s.append(edges[i][j] + " ");
            }
            s.append("\n");
        }
        return s.toString();
    }

    public Integer[] neighborsArray(int from) {
        return this.edges[from];
    }
    
    public static GraphMatrix readfromFile(String f) {
        // TODO code application logic here

        try {
            Scanner sc = new Scanner(new File(f));
            int v = sc.nextInt();
            int e = sc.nextInt();
            System.out.println("constructing a graph of " + v + " vertices and "
                    + e + " edges ");
            GraphMatrix g1 = new GraphMatrix(v);
            for (int i = 0; i < e; i++) {
                int v1 = sc.nextInt();
                int v2 = sc.nextInt();
                g1.addEdge(v1, v2,1);
            }
            System.out.println("Loaded " + e + " edges ");
            return g1;

        } catch (FileNotFoundException e) {
            System.out.println(e.toString());
            return null;
        }
    }

    
}
