import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        MainGraph graph = new MainGraph();
        Scanner sc = new Scanner(System.in);
        System.out.println("1.ReadGraphFromFile\n" +
                "2. IsThereAPath\n" +
                "3. AllPathsShorterThanEqualTo \n" +
                "4. ShortestPathLengthFromTo \n" +
                "5. NoOfPathsFromTo \n" +
                "6. BFSfromTo\n" +
                "7. DFSfromTo \n" +
                "8. NoOfVerticesInComponent\n");
        while (true) {
            int a = Integer.parseInt(sc.nextLine());
            switch (a) {
                case 1:
                    graph.ReadGraphFromFile("GameOfThronesList.txt");
                    break;
                case 2:
                    System.out.println("Enter the first name");
                    String name = sc.nextLine();

                    System.out.println("Enter the second name:");

                    String name2 = sc.nextLine();
                    System.out.println("you entered:" + name + " and " + name2);
                    if(graph.IsThereAPath(name, name2)) {
                        System.out.println("true");
                    } else {
                        System.out.println("false");
                    }
                    break;
                case 3:
                    System.out.println("Enter the path length");
                    int pathLen = Integer.parseInt(sc.nextLine());

                    System.out.println("Enter minimum vertex number:");

                    int vertexNo = Integer.parseInt(sc.nextLine());

                    System.out.println("Enter the name");
                    name = sc.nextLine();

                    System.out.println("you entered:" + pathLen + "," + vertexNo + " and " + name);
                    graph.AllPathsShorterThanEqualTo(pathLen, vertexNo, name);
                    break;
                case 4:
                    System.out.println("Enter the first name");
                    name = sc.nextLine();

                    System.out.println("Enter the second name:");

                    name2 = sc.nextLine();
                    System.out.println("you entered:" + name + " and " + name2);
                    graph.ShortestPathLengthFromTo(name, name2);
                    break;
                case 5:
                    System.out.println("Enter first name");
                    name = sc.nextLine();
                    System.out.println("Enter the second name:");
                    name2 = sc.nextLine();
                    System.out.println("you entered:" + name + " and " + name2);
                    graph.NoOfPathsFromTo(name, name2);
                    break;
                case 6:
                    System.out.println("Enter first name");
                    name = sc.nextLine();
                    System.out.println("Enter the second name:");
                    name2 = sc.nextLine();
                    System.out.println("you entered:" + name + " and " + name2);
                    graph.BFSfromTo(name, name2);
                    break;
                case 7:
                    System.out.println("Enter first name");
                    name = sc.nextLine();
                    System.out.println("Enter the second name:");
                    name2 = sc.nextLine();
                    System.out.println("you entered:" + name + " and " + name2);
                    graph.DFSfromTo(name, name2);
                    break;
                case 8:
                    System.out.println("Enter  name");
                    name = sc.nextLine();
                    System.out.println("you entered:" + name);
                    graph.NoOfVerticesInComponent(name);
                    break;
                default:
                    System.out.println("enter valid number.");
                    break;

            }
        }
    }

}