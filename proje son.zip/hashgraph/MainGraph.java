import java.io.*;
import java.util.*;

public class MainGraph {
    private GraphMatrix graph;
    private LinearProbingHash<String> hash;
    private int graphSize;
    private boolean isTherePath = false;

    public void ReadGraphFromFile(String path) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(path));
            int graphIndexX = 0, graphIndexY = 0;
            ArrayList<String> set = new ArrayList<>();
            ArrayList<String> array = new ArrayList<>();
            while (reader.ready()) {
                String stringValue = reader.readLine();
                array.add(stringValue);
                String parts[] = stringValue.split(",");
                if (!set.contains(parts[0])) {
                    set.add(parts[0]);
                }
                if (!set.contains(parts[1])) {
                    set.add(parts[1]);
                }
            }
            System.out.println(set.size());
            this.graph = new GraphMatrix(set.size());
            this.hash = new LinearProbingHash<String>(set.size());
            this.graphSize = set.size();
            for (int i = 0; i < array.size(); i++) {
                String stringValue = array.get(i);
                String parts[] = stringValue.split(",");
                if (hash.contains(parts[0]) != -1) {
                    graphIndexX = hash.contains(parts[0]);
                } else {
                    hash.insert(parts[0]);
                    graphIndexX = hash.contains(parts[0]);
                }
                if (hash.contains(parts[1]) != -1) {
                    graphIndexY = hash.contains(parts[1]);
                } else {
                    hash.insert(parts[1]);
                    graphIndexY = hash.contains(parts[1]);
                }
                graph.addEdge(graphIndexX, graphIndexY, Integer.parseInt(parts[2]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean IsThereAnEdge(String name1, String name2) {
        if (this.hash.contains(name1) == -1 || this.hash.contains(name2) == -1)
            System.out.println("Input is invalid");
        else {
            int name1X = hash.contains(name1), name2X = hash.contains(name2);
            if (name1X == -1) {
                return false;
            }
            if (name2X == -1) {
                return false;
            }
            if (!(graph.isAdjacent(name1X, name2X))) {
                return false;
            }
            return true;
        }
        return false;

    }

    public void dfsForSearchPath(String path,String name, String target, int[] isVisited) {
        int indexY = hash.contains(name);
        isVisited[indexY] = 1;
        path+=name+",";
        if (name.equals(target)) {
            System.out.println(path);
            this.isTherePath = true;
        }
        for (int i = 0; i < graph.numV; i++) {
            if (IsThereAnEdge(name, this.hash.getKey(i)) && isVisited[i] == 0 && !isTherePath) {
                dfsForSearchPath(path,this.hash.getKey(i), target, isVisited);
            }
        }
    }

    public boolean IsThereAPath(String name1, String name2) {
        int[] isVisited = new int[this.graphSize];
        if (this.hash.contains(name1) == -1 || this.hash.contains(name2) == -1)
            System.out.println("Input is invalid");
        else {
            dfsForSearchPath("",name1, name2, isVisited);
            if (this.isTherePath == false)
                return false;
            this.isTherePath = false;
            return true;
        }
        return false;
    }

    public void dfsForShorterThanEqualTo(String path, int length, int pathLen, int vertexNo, int totalVertex,
            ArrayList<String> allPaths, String name) {
        int indexY = hash.contains(name);
        int indexX = -1;
        if (!path.equals(""))
            indexX = hash.contains(path.split(",")[path.split(",").length - 1]);
        if (path.equals("")) {
            path += name;
        } else
            path += "," + name;

        if (indexX != -1 && graph.graphWeight(indexX, indexY) <= pathLen && totalVertex + 1 >= vertexNo) {
            allPaths.add(path);
        }
        for (int i = 0; i < graph.numV; i++) {
            if (IsThereAnEdge(name, this.hash.getKey(i)) && graph.graphWeight(indexY, i) + length <= pathLen
                    && path.indexOf(this.hash.getKey(i)) == -1) {
                dfsForShorterThanEqualTo(path, length + graph.graphWeight(indexY, i), pathLen, vertexNo,
                        totalVertex + 1,
                        allPaths, this.hash.getKey(i));
            }
        }
    }

    public void AllPathsShorterThanEqualTo(int pathLen, int vertexNo, String name1) {
        ArrayList<String> allPaths = new ArrayList<>();
        if (this.hash.contains(name1) == -1)
            System.out.println("Input is invalid");
        else {
            dfsForShorterThanEqualTo("", 0, pathLen, vertexNo, 0, allPaths, name1);
            for (int i = 0; i < allPaths.size(); i++) {
                System.out.println(allPaths.get(i));
            }
        }
    }

    public void dfsForShorter(String path, int length, ArrayList<String> allPaths, String name, String target,
            ArrayList<Integer> allPathsSize) {
        int indexY = hash.contains(name);
        if (path.equals("")) {
            path += name;
        } else
            path += "," + name;
        if (name.equals(target)) {
            allPaths.add(path);
            allPathsSize.add(length);
        }
        for (int i = 0; i < graph.numV; i++) {
            if (IsThereAnEdge(name, this.hash.getKey(i)) && path.indexOf(this.hash.getKey(i)) == -1) {
                dfsForShorter(path, length + graph.graphWeight(indexY, i), allPaths, this.hash.getKey(i), target,
                        allPathsSize);
            }
        }
    }

    public void ShortestPathLengthFromTo(String name1, String name2) {
        ArrayList<String> allPaths = new ArrayList<>();
        ArrayList<Integer> allPathsSize = new ArrayList<>();
        if (this.hash.contains(name1) == -1 || this.hash.contains(name2) == -1) {

            System.out.println("Input is invalid");
            return;
        }
        dfsForShorter("", 0, allPaths, name1, name2, allPathsSize);
        if (allPathsSize.size() == 0)
            System.out.println("infinty");
        else {
            int min = allPathsSize.get(0);
            for (int i = 0; i < allPathsSize.size(); i++) {
                if (min > allPathsSize.get(i)) {
                    min = allPathsSize.get(i);
                }
            }
            System.out.println(min);

        }
    }

    public void NoOfPathsFromTo(String name1, String name2) {
        ArrayList<String> allPaths = new ArrayList<>();
        ArrayList<Integer> allPathsSize = new ArrayList<>();
        if (this.hash.contains(name1) == -1 || this.hash.contains(name2) == -1) {

            System.out.println("Input is invalid");
            return;
        }
        dfsForShorter("", 0, allPaths, name1, name2, allPathsSize);
        System.out.println(allPaths.size());
    }

    public void DFSfromTo(String name1, String name2) {
        ArrayList<String> allPaths = new ArrayList<>();
        ArrayList<Integer> allPathsSize = new ArrayList<>();
        if (this.hash.contains(name1) == -1 || this.hash.contains(name2) == -1) {

            System.out.println("Input is invalid");
            return;
        }
        int[] isVisited = new int[this.graphSize];
        dfsForSearchPath("",name1, name2, isVisited);
        if (this.isTherePath == false)
            System.out.println("No path");
        this.isTherePath = true;
    }

    public void BFSfromTo(String name1, String name2) {
        if (this.hash.contains(name1) == -1 || this.hash.contains(name2) == -1) {

            System.out.println("Input is invalid");
            return;
        }
        Integer[] isVisited = new Integer[this.graphSize];
        for (int i = 0; i < isVisited.length; i++) {
            isVisited[i] = 0;
        }
        LinkedList<Integer> q = new LinkedList<>();
        q.addLast(this.hash.contains(name1));
        String path = "";
        int flag = 0;
        while (!q.isEmpty()) {
            int source = q.removeFirst();
            Integer[] a = graph.neighborsArray(source);
            Integer[][] array = new Integer[this.graphSize][2];
            for (int i = 0; i < this.graphSize; i++) {
                array[i][0] = a[i];
                array[i][1] = i;
            }
            for (int i = 0; i < array.length; i++) {
                for (int j = 0; j < array.length - i - 1; j++) {
                    if (array[j][0] > array[j + 1][0]) {
                        Integer[] tmp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = tmp;
                    }
                }
            }
            isVisited[source] = 1;
            path += this.hash.getKey(source) + ",";
            if (this.hash.getKey(source).equals(name2)) {
                flag = 1;
                break;
            }
            for (int i = 0; i < array.length; i++) {
                if (isVisited[array[i][1]] == 0
                        && IsThereAnEdge(this.hash.getKey(source), this.hash.getKey(array[i][1]))) {
                    q.addLast(array[i][1]);
                    isVisited[array[i][1]] = 1;
                }
            }
        }

        if (flag == 0)
            System.out.println("No path");
        else
            System.out.println(path);
    }

    public void NoOfVerticesInComponent(String name1) {
        int[] isVisited = new int[this.graphSize];
        for (int i = 0; i < isVisited.length; i++) {
            isVisited[i] = 0;
        }
        searchComponentVertexNo(isVisited, name1);
        int totalVertexNo = 0;
        for (int i = 0; i < isVisited.length; i++) {
            totalVertexNo += isVisited[i];
        }
        System.out.println(totalVertexNo);
    }

    public void searchComponentVertexNo(int[] isVisited, String name) {
        isVisited[this.hash.contains(name)] = 1;
        for (int i = 0; i < graph.numV; i++) {
            if (IsThereAnEdge(name, this.hash.getKey(i)) && isVisited[i] == 0) {
                searchComponentVertexNo(isVisited, this.hash.getKey(i));
            }
        }
    }
}